package Entidades;

public class Login {
    private String Usuario;
    private String Senha;

    public String getSenha() {
        return Senha;
    }
    public void setSenha(String Senha) {
        this.Senha = Senha;
    }
    public String getUsuario(){
        return Usuario;}

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

}